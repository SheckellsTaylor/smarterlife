<link href="/css/slider-pro.css" rel="stylesheet">
<script type="text/javascript" src="/js/slider-pro.js"></script>

<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery('#{{ $id }}').sliderPro({!! $options !!});
    });
</script>